var zlib = require('zlib');


const gzip = zlib.createGzip();
var fs = require('fs');
var inp = fs.createReadStream('data.txt');
var out = fs.createWriteStream('output.text.gz');

inp.pipe(gzip).pipe(out);