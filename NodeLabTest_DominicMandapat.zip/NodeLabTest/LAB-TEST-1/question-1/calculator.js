function multiplyTwoNumbers(x,y){
    if(!isInteger(x) || !isInteger(y)) {
        throw new Error();
    }
    return x * y;
}

function evenDoubler(x){
    if(!isInteger(x)) {
        throw new Error()
    }
    if(x%2 == 1){
        return 0; 
    }
    else{
        return x * x;
    }
}

var isInteger = function (param) {
    return Number.isInteger(param);
}

module.exports = {
    multiplyTwoNumbers: multiplyTwoNumbers,
    evenDoubler: evenDoubler
}