const http = require('http');
const osinfo = require('./osinfo');

const hostname = '127.0.0.1';
const port = 3000;

const server = http.createServer(function (req, res) {
    res.writeHead(200, { 'Content-Type': 'application/json'});

    if(req.url === '/') {
        res.writeHead(200, { 'Content-Type': 'application/json'});
        res.end('No data found');
      }
    
    else if(req.url === '/api/systeminfo') {
        res.writeHead(200, { 'Content-Type': 'application/json'});
    
        var systeminfo = osinfo.systeminfo.getSysteminfo();
        console.log(systeminfo);
    
        res.end(JSON.stringify(systeminfo));
      }
    else if(req.url === '/api/userinfo') {
        res.writeHead(200, { 'Content-Type': 'application/json'});
    
        var userinfo = osinfo.systeminfo.getUserinfo();
        console.log(userinfo);
    
        res.end(JSON.stringify(userinfo));
      }
    else if(req.url === '/api/firewall') { 
        res.writeHead(200, { 'Content-Type': 'application/json'});
        
        var firewall = osinfo.firewall.getStatuses();
        console.log(firewall);
    
        res.end(JSON.stringify(firewall));
      }
    else {
            // request not found, send back 404
            var errorMessage = 'Error - page not found';
            res.writeHead(404, errorMessage);
            res.end(errorMessage);
      }
});



server.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`)
});