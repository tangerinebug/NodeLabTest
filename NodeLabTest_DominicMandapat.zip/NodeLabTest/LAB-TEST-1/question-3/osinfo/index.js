var systeminfo = require("./systeminfo");
var firewall = require("./firewall");

module.exports = {
    systeminfo: systeminfo,
    firewall: firewall
}