var os = require('os');

function getSysteminfo(){
    var arch = os.arch();
    var host = os.hostname();
    var osname = os.type();
    return {architecture: arch, name: host, osname: osname};
}

function getUserinfo(){
    var uname = os.userInfo();
    return {username: uname.username, dir: uname.homedir};
}

module.exports = {
    getSysteminfo: getSysteminfo,
    getUserinfo: getUserinfo
}