function getStatuses(){
    var arr = ["OK", "ALLOW", "DENY", "BLOCK"];
    return {arr};
}

module.exports = {
    getStatuses: getStatuses
}